// GANTI ISI CONFIG INI DENGAN PUNYA LO DARI FIREBASE
const firebaseConfig = {
  apiKey: "AIzaSy....",
  authDomain: "igris-store.firebaseapp.com",
  projectId: "igris-store",
  storageBucket: "igris-store.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcd"
};

firebase.initializeApp(firebaseConfig);